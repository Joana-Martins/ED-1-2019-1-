#include "pilha.h"

Pilha* cria_pilha(){
  Pilha* p;
  p = malloc(sizeof(Pilha));
  p -> Topo = malloc(sizeof(Celula));
  p-> Fundo = malloc(sizeof(Celula));
  p -> Fundo -> Prox = malloc(sizeof(Celula));
  p -> Topo -> Prox = NULL;
  p -> tamanho = 0;

  return p;
}


void push (int n, Pilha* pilha){
  Celula *aux;
  aux =malloc(sizeof(Celula));
  if(pilha == NULL){
    printf("Pilha inválida. Error.\n");
    exit(0);
  }

  Pilha->Topo->Item = n;
	Aux->Prox = Pilha->Topo;
	Pilha->Topo = Aux;
	Pilha->Tamanho++;

}
