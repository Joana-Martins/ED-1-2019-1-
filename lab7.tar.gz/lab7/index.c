#include "pilha.h"


void main(){

  Pilha *pilha1;
  Pilha *pilha2;
  pilha1 = cria_pilha();
  pilha2 = cria_pilha();

}
